# Your new SandBox website

- `dist/` contains the complete ready-to-host website.
- English: `/`
- Arabic: `/ar/`
- `src/site-config.js` is where you add contact details and change the included Veo video settings.
- `src/i18n.json` is where you change the wording in both languages.
- After editing, run `python3 build.py`.
- To preview: `python3 -m http.server 8080 --directory dist`.

The project form currently prepares a downloadable brief. It does not send it anywhere.

See `README.md` for the full editing and hosting guide.
