// Add public business details here when they are ready. Never put API keys here.
window.SANDBOX_CONFIG = {
  contact: {
    email: '',
    whatsapp: '', // International digits, for example country code followed by number.
    social: [] // Example structure: { label: 'Instagram', url: 'https://...' }
  },
  media: {
    showreel: '/assets/sandbox-showreel.mp4',
    poster: '/assets/sandbox-showreel-poster.jpg'
  }
};
