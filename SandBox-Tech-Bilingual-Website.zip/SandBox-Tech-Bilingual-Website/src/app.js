(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const lang = document.documentElement.lang === 'ar' ? 'ar' : 'en';
  const copy = window.SANDBOX_LOCALES[lang];
  const t = key => copy[key] || key;
  const config = window.SANDBOX_CONFIG || {};
  const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)');
  let paused = Boolean(reduced?.matches);
  let autoTimers = [];
  let flowTimers = [];
  let flowRunning = false;
  let lastFocus = null;
  let view = 'preview';
  const samples = {
    week: { interactions: 2480, completion: 84, days: '07', values: [94, 78, 83, 48, 63, 30, 41, 10] },
    month: { interactions: 10240, completion: 91, days: '30', values: [98, 91, 67, 78, 44, 50, 21, 12] }
  };
  const period = $('#period');
  const status = message => { $('#announcement').textContent = message; };
  const safeText = value => String(value).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  const stopAuto = () => { autoTimers.forEach(clearTimeout); autoTimers = []; };
  const setView = (name, user = false) => {
    if (!['preview', 'code', 'system'].includes(name)) return;
    if (user) stopAuto();
    view = name;
    $$('[data-view]').forEach(button => {
      const active = button.dataset.view === name;
      button.setAttribute('aria-selected', String(active));
      button.tabIndex = active ? 0 : -1;
      $('#view-' + button.dataset.view).hidden = !active;
    });
    $('#build-index').textContent = ({preview:'01—03', code:'02—03', system:'03—03'})[name];
    const panel = $('#view-' + name);
    if (!paused && panel.animate) panel.animate([{opacity:.3, transform:'translateY(5px)'},{opacity:1, transform:'translateY(0)'}], {duration:260,easing:'ease-out'});
  };
  const renderDashboard = () => {
    const data = samples[period.value] || samples.week;
    $('#metric').textContent = new Intl.NumberFormat(lang).format(data.interactions);
    $('#completion').innerHTML = `${data.completion}<span>%</span>`;
    $('#axis-end').textContent = data.days;
    const points = data.values.map((value,index) => `${index ? 'L' : 'M'}${Math.round(index * 400 / 7)} ${value}`).join('');
    $('#chart-line').setAttribute('d', points);
    $('#chart-area').setAttribute('d', points + 'V110H0Z');
  };
  const finishFlow = () => {
    const data = samples[period.value];
    renderDashboard();
    $('#console-output').textContent = t('flowDone') + data.interactions.toLocaleString('en') + t('flowInteractions');
    $$('.flow-node').forEach(node => node.classList.add('active'));
    $('#run-flow').disabled = false;
    flowRunning = false;
    status(t('flowAnnounce'));
  };
  const runFlow = () => {
    if (flowRunning) return;
    flowTimers.forEach(clearTimeout);
    setView('system');
    $$('.flow-node').forEach(node => node.classList.remove('active'));
    flowRunning = true;
    $('#run-flow').disabled = true;
    $('#console-output').textContent = t('flowInput') + period.value;
    $('[data-step="0"]').classList.add('active');
    if (paused) { finishFlow(); return; }
    flowTimers.push(setTimeout(() => {
      $('[data-step="1"]').classList.add('active');
      $('#console-output').textContent = t('flowProcess');
    }, 600));
    flowTimers.push(setTimeout(finishFlow, 1350));
  };
  const playBuild = () => {
    stopAuto();
    flowTimers.forEach(clearTimeout);
    flowRunning = false;
    $('#run-flow').disabled = false;
    if (paused) { setView('preview'); return; }
    setView('code');
    autoTimers.push(setTimeout(() => setView('preview'), 1600));
    autoTimers.push(setTimeout(() => { setView('system'); runFlow(); }, 3500));
    autoTimers.push(setTimeout(() => setView('preview'), 6200));
  };
  const syncMotion = () => {
    document.body.classList.toggle('motion-paused', paused);
    const button = $('#motion-toggle');
    button.setAttribute('aria-pressed', String(paused));
    button.setAttribute('aria-label', t(paused ? 'resumeMotion' : 'pauseMotion'));
    button.textContent = paused ? '▷' : 'Ⅱ';
    if (paused) { stopAuto(); flowTimers.forEach(clearTimeout); if (flowRunning) finishFlow(); }
  };
  $('#motion-toggle').addEventListener('click', () => { paused = !paused; syncMotion(); });
  reduced?.addEventListener?.('change', event => { paused = event.matches; syncMotion(); });
  $$('.workspace-tabs [data-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.view, true)));
  $('.workspace-tabs').addEventListener('keydown', event => {
    const tabs = $$('[data-view]');
    const index = tabs.indexOf(document.activeElement);
    if (index < 0) return;
    let next;
    if (event.key === 'ArrowRight') next = (index + (lang === 'ar' ? 2 : 1)) % 3;
    else if (event.key === 'ArrowLeft') next = (index + (lang === 'ar' ? 1 : 2)) % 3;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = 2;
    else return;
    event.preventDefault(); setView(tabs[next].dataset.view,true); tabs[next].focus();
  });
  period.addEventListener('change', () => { stopAuto(); renderDashboard(); });
  period.addEventListener('focus', stopAuto);
  $('#run-flow').addEventListener('click', () => { stopAuto(); runFlow(); });
  $('#connect-demo').addEventListener('click', () => { stopAuto(); runFlow(); $('#tab-system').focus(); });
  $('#play-build').addEventListener('click', () => {
    if (config.media?.showreel) { openFilm(); return; }
    playBuild();
    $('#build-stage').scrollIntoView?.({behavior:paused?'instant':'smooth',block:'center'});
  });
  $('#build-stage').addEventListener('pointerdown', event => { if (!event.target.closest('#motion-toggle')) stopAuto(); });
  const menu = $('#menu');
  menu.addEventListener('click', () => {
    const open = menu.getAttribute('aria-expanded') !== 'true';
    menu.setAttribute('aria-expanded',String(open)); $('#mobile-nav').hidden = !open;
  });
  $$('#mobile-nav a, #mobile-nav button').forEach(item => item.addEventListener('click', () => { menu.setAttribute('aria-expanded','false'); $('#mobile-nav').hidden = true; }));
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('#mobile-nav').hidden) { menu.setAttribute('aria-expanded','false'); $('#mobile-nav').hidden = true; menu.focus(); } });

  const card = $('#lab-card');
  const title = $('#product-title');
  const radius = $('#radius');
  const labMotion = $('#lab-motion');
  const accent = () => $('input[name="accent"]:checked').value;
  const updateLab = () => {
    $('#live-title').textContent = title.value.trim() || t('defaultProduct');
    card.style.setProperty('--radius', radius.value + 'px');
    card.style.setProperty('--lab-accent', accent());
    card.classList.toggle('interactive', labMotion.checked);
    $('#radius-output').value = radius.value + 'px';
    $('#css-radius').textContent = radius.value + 'px';
    $('#css-accent').textContent = accent();
    $('#copy-status').textContent = '';
  };
  [title,radius,labMotion,...$$('input[name="accent"]')].forEach(input => input.addEventListener('input', updateLab));
  $('#lab-card-action').addEventListener('click', () => {
    card.classList.remove('pulse');
    if (!paused) { void card.offsetWidth; card.classList.add('pulse'); }
    $('#lab-action-status').textContent = t('interactionDone');
    $('#lab-card-action').textContent = '✓ ' + t('interactionDone');
    setTimeout(() => { $('#lab-card-action').innerHTML = safeText(t('launchExperience')) + ' <span aria-hidden="true">↗</span>'; },1800);
  });
  $('#reset-lab').addEventListener('click', () => {
    title.value = t('defaultProduct'); radius.value = '16'; labMotion.checked = true;
    $('input[name="accent"][value="#FF6B35"]').checked = true;
    updateLab(); status(t('labReset'));
  });
  const download = (text, filename, mime='text/plain;charset=utf-8') => {
    const url = URL.createObjectURL(new Blob([text],{type:mime}));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename;
    document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url),1000);
  };
  const cssText = () => `.your-component {\n  --accent: ${accent()};\n  border-radius: ${radius.value}px;\n  padding: 24px;\n  color: #F6F2EA;\n  background: #252D2F;\n  border: 1px solid #526466;\n${labMotion.checked ? '  transition: transform 300ms ease, border-color 300ms ease;\n' : ''}}\n\n.your-component button {\n  background: var(--accent);\n  color: #142024;\n}\n${labMotion.checked ? '\n@media (prefers-reduced-motion: no-preference) {\n  .your-component:hover {\n    transform: translateY(-5px);\n    border-color: var(--accent);\n  }\n}\n' : ''}`;
  $('#copy-css').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(cssText()); $('#copy-status').textContent = t('cssCopied'); }
    catch { download(cssText(),'sandbox-component.css','text/css;charset=utf-8'); $('#copy-status').textContent = t('copyDownload'); }
  });

  const openDialog = dialog => {
    stopAuto(); lastFocus = document.activeElement;
    $$('video').forEach(video => video.pause());
    dialog.showModal(); $('.close-dialog', dialog)?.focus();
  };
  $$('dialog').forEach(dialog => {
    $('[data-close]',dialog).addEventListener('click',() => dialog.close());
    dialog.addEventListener('click',event => { if(event.target===dialog) { const box=dialog.getBoundingClientRect(); if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom) dialog.close(); } });
    dialog.addEventListener('close',() => { $$('video',dialog).forEach(video=>video.pause()); if(lastFocus?.isConnected) lastFocus.focus(); });
  });
  $$('[data-brief]').forEach(button => button.addEventListener('click', () => openDialog($('#brief-dialog'))));
  $$('[data-privacy]').forEach(button => button.addEventListener('click', () => openDialog($('#privacy-dialog'))));
  const projectContent = name => {
    const isRoamli = name === 'roamli';
    const label = isRoamli ? 'ROAMLI' : 'Collab';
    const photo = isRoamli ? '/assets/roamli-home.png' : '/assets/collab-portfolio.jpeg';
    return `<div class="case-heading"><div><h2 dir="ltr">${label}</h2><p class="case-tagline">${safeText(t(name+'Tagline'))}</p></div><div class="tags"><span>${safeText(t('productDesign'))}</span><span>${isRoamli?'Flutter':'React Native'}</span><span>${safeText(t('inDevelopment'))}</span></div></div><div class="case-body"><div class="case-content"><h3>${safeText(t('challenge'))}</h3><p>${safeText(t(name+'Challenge'))}</p><h3>${safeText(t('approach'))}</h3><p>${safeText(t(name+'Approach'))}</p><h3>${safeText(t('builtFeatures'))}</h3><ul>${[1,2,3].map(n=>'<li>'+safeText(t(name+'Feature'+n))+'</li>').join('')}</ul><p class="case-status"><strong>${safeText(t('projectStatus'))}</strong><br>${safeText(t(name+'Status'))}</p>${isRoamli?`<p class="video-caption">${safeText(t('watchIntro'))}</p><video class="case-video" controls playsinline preload="none" aria-label="${safeText(t('watchIntro'))}"><source src="/assets/roamli-intro.mp4" type="video/mp4"></video>`:''}</div><div class="case-preview ${name}"><img src="${photo}" alt="${safeText(t(isRoamli?'roamliImageAlt':'collabImageAlt'))}" width="${isRoamli?780:1086}" height="${isRoamli?1688:1448}"></div></div>`;
  };
  const openProject = name => {
    if(!['collab','roamli'].includes(name)) return;
    $('#project-content').innerHTML = projectContent(name);
    $('#project-dialog').setAttribute('aria-label',name==='collab'?'Collab':'ROAMLI');
    openDialog($('#project-dialog'));
  };
  $$('[data-project]').forEach(link=>link.addEventListener('click',event=>{ event.preventDefault(); openProject(link.dataset.project); }));
  if(['#collab','#roamli'].includes(location.hash)) openProject(location.hash.slice(1));
  const openFilm = () => {
    const path = config.media?.showreel;
    if(!path || !(path.startsWith('/') && !path.startsWith('//'))) return;
    const poster = config.media.poster?.startsWith('/') && !config.media.poster.startsWith('//') ? config.media.poster : '';
    $('#project-content').innerHTML = `<h2>${safeText(t('showreelTitle'))}</h2><p class="film-modal-description">${safeText(t('filmDescription'))}</p><video controls playsinline preload="metadata" class="film-video modal-film" width="910" height="512" aria-label="${safeText(t('filmAlt'))}" poster="${safeText(poster)}" src="${safeText(path)}"></video>`;
    $('#project-dialog').setAttribute('aria-label',t('showreelTitle'));
    openDialog($('#project-dialog'));
  };
  if(config.media?.showreel?.startsWith('/') && !config.media.showreel.startsWith('//')) $('#play-build').innerHTML = '<span class="play-icon" aria-hidden="true">▷</span>' + safeText(t('watchFilm'));
  const studioFilm = $('#studio-film');
  if(studioFilm && config.media?.showreel?.startsWith('/') && !config.media.showreel.startsWith('//')) {
    $('source',studioFilm).src = config.media.showreel;
    if(config.media.poster?.startsWith('/') && !config.media.poster.startsWith('//')) studioFilm.poster = config.media.poster;
    studioFilm.addEventListener('play',() => { stopAuto(); $$('video').filter(video=>video!==studioFilm).forEach(video=>video.pause()); });
  }

  const form = $('#brief-form');
  const projectTypes = {web:'webTitle',mobile:'mobileTitle',automation:'aiTitle',design:'designTitle'};
  const briefText = () => {
    const values = new FormData(form);
    return `${t('briefTitle')}\n${'='.repeat(32)}\n\n${t('briefDate')}: ${new Date().toISOString().slice(0,10)}\n${t('yourName')}: ${values.get('name').trim()}\n${t('businessName')}: ${values.get('business').trim() || '—'}\n${t('briefType')}: ${t(projectTypes[values.get('type')])}\n\n${t('briefIdea')}\n${values.get('idea').trim()}\n\n${t('briefFooter')}\n`;
  };
  form.addEventListener('submit',event => {
    event.preventDefault(); if(!form.reportValidity()) return;
    download('\uFEFF'+briefText(),'SandBox-Project-Brief-'+lang+'.txt');
    $('#brief-status').textContent = t('briefDownloaded');
  });
  $('#copy-brief').addEventListener('click',async () => {
    if(!form.reportValidity()) return;
    try { await navigator.clipboard.writeText(briefText()); $('#brief-status').textContent = t('briefCopied'); }
    catch { download('\uFEFF'+briefText(),'SandBox-Project-Brief-'+lang+'.txt'); $('#brief-status').textContent = t('briefDownloaded'); }
  });
  const contact = config.contact || {};
  const email = typeof contact.email==='string' && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(contact.email) ? contact.email : '';
  const phone = typeof contact.whatsapp==='string' ? contact.whatsapp.replace(/[^0-9]/g,'') : '';
  const contactButton = $('#configured-contact');
  if(email || phone.length>=8) {
    contactButton.hidden=false; contactButton.textContent=t('contactLabel');
    contactButton.href=email?'mailto:'+encodeURIComponent(email):'https://wa.me/'+phone;
  }
  if(Array.isArray(contact.social)) contact.social.forEach(item=>{
    try { const url=new URL(item.url); if(url.protocol!=='https:') return; const a=document.createElement('a');a.href=url.href;a.textContent=String(item.label).slice(0,40);a.target='_blank';a.rel='noopener noreferrer';$('#social-links').append(a); } catch {}
  });
  $('#year').textContent = new Date().getFullYear();
  document.addEventListener('visibilitychange', () => { if(document.hidden) stopAuto(); });
  renderDashboard(); updateLab(); syncMotion();
  if(!paused && !location.hash) { setView('code'); autoTimers.push(setTimeout(()=>setView('preview'),1800)); }
})();
