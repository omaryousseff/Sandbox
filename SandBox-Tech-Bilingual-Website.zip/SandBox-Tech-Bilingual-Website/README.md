# SandBox — bilingual technology studio

A complete static redesign of the SandBox website, with English and Arabic pages, a dark brand palette, interactive demonstrations, Collab and ROAMLI project stories, and a downloadable project brief.

## Start here

The ready-to-host website is in `dist/`. It works without a framework, an API key, or a database.

To preview locally from this folder:

```bash
python3 -m http.server 8080 --directory dist
```

Open `http://localhost:8080/` for English or `http://localhost:8080/ar/` for Arabic. Use an HTTP server; opening the HTML directly from a file manager does not resolve root-relative assets correctly.

## Edit the site

| File | Purpose |
| --- | --- |
| `src/index.template.html` | Shared layout for both languages |
| `src/i18n.json` | English and Arabic website text, labels and project stories |
| `src/styles.css` | Responsive layout, brand styling, motion and right-to-left rules |
| `src/app.js` | Working demonstrations, project dialogs and brief download |
| `src/site-config.js` | Public contact details and showreel settings |
| `dist/assets/` | Original brand and project assets, fonts and ROAMLI intro video |
| `build.py` | Generates both static language pages and copies the source files |

After any source edit run:

```bash
python3 build.py
```

Then publish the contents of `dist/` to a static host at the domain root. Both `/` and `/ar/` must serve their `index.html`. The `.openai/hosting.json` file retains the existing Sites project identity; it is not needed for another hosting service. Do not upload project source or `.git` as the public web root.

## Add your contact details later

Edit `src/site-config.js`:

- `contact.email`: your business email address.
- `contact.whatsapp`: the international phone number, including country code.
- `contact.social`: entries with `label` and a full `https://` URL.

Rebuild. The site automatically displays a contact button when an email or valid-length WhatsApp number is supplied, and displays supplied social links. An email takes precedence for the main contact button. Contact links are opened by the visitor; the site does not send messages automatically.

The brief form currently downloads or copies a text file. It does **not** submit an enquiry, deliver an email, or save customer information on a server. Setting contact details adds direct contact links; it does not silently convert the brief form into a submission service.

## Included video and future replacements

The supplied ten-second Veo film is included as `dist/assets/sandbox-showreel.mp4`, with its original audio and picture preserved. Its MP4 metadata was moved to the start for progressive loading. A frame from the same film supplies the poster.

The film appears below the opening section in both languages and is also available through “Watch the film” / “شاهد الفيديو”. Native controls let visitors choose playback, volume and full screen. It does not autoplay or load the complete video on page entry. Opening a dialog pauses any other video.

ROAMLI's existing four-second intro remains in its project story.

To replace the SandBox film later, replace the MP4 and poster in `dist/assets/`, or change `media.showreel` and `media.poster` in `src/site-config.js`, then run `python3 build.py`. If the film's duration changes, update `film-duration` in `src/index.template.html`.

## What works

- Direct English and Arabic URLs, translated content and RTL layouts.
- Mobile navigation, keyboard-operable demo tabs and native dialogs.
- A dashboard with two sample datasets and an animated local data-flow demonstration.
- An editable interface component with colour, title, radius and hover controls; CSS copy/download and reset.
- Collab and ROAMLI project stories using the retrieved project source and original visual assets.
- The supplied SandBox brand film and a browser-native ROAMLI intro video player.
- Project brief validation, copy and download.
- Reduced-motion handling, pause control, meaningful alternative text and visible focus styles.
- No analytics cookies, advertising trackers or remote API calls added by the site.

The app previews and dashboard use demonstration content. Collab's portfolio image is a design reference, while ROAMLI's screens are app previews. Project stories describe the current development status; no deployment, user-count, revenue, payment or live-integration claims are invented.

## Validation and limits

JavaScript syntax and both generated language pages were checked. DOM integration checks passed for navigation, static asset references, duplicate IDs, language direction, dashboard changes, workflow execution, keyboard tabs, safe live editing, CSS copy/reset, project dialogs, video references, project brief copy/download, and the mobile menu. CSS parsed successfully in the DOM test environment. The included video was checked as an H.264 MP4 (720 × 1440, 4 seconds).

A rendered browser/device visual review was not available for this static execution path. The DOM checks do not replace testing on actual devices. Contact information remains pending as agreed. The supplied SandBox film is integrated.

## Brand and assets

SandBox: Ink `#181A1B`, Ivory `#F6F2EA`, Ember `#FF6B35`; Sora headings and Inter body text, with system Arabic type. The original supplied mark is preserved. Project visuals and ROAMLI video come from the owner's provided app packages. The SandBox brand film was supplied separately by the owner. Font licences are in `dist/assets/fonts/`.
