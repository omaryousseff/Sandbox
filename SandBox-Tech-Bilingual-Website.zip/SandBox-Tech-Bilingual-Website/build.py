"""Generate static English and Arabic pages. Requires Python 3, no dependencies."""
import json
import re
import shutil
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'src'
OUT = ROOT / 'dist'
locales = json.loads((SRC / 'i18n.json').read_text())
template = (SRC / 'index.template.html').read_text()
keys = set(re.findall(r'\{\{(\w+)\}\}', template))
assert set(locales['en']) == set(locales['ar']), 'Locale keys differ'
for language in ['en', 'ar']:
    assert not keys - locales[language].keys(), f'Missing translation: {keys-locales[language].keys()}'
    html = re.sub(r'\{\{(\w+)\}\}', lambda m: escape(locales[language][m[1]], quote=True), template)
    target = OUT / ('ar/index.html' if language == 'ar' else 'index.html')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(html)
for name in ['styles.css', 'app.js', 'site-config.js']:
    shutil.copyfile(SRC / name, OUT / name)
(OUT / 'locales.js').write_text('window.SANDBOX_LOCALES = ' + json.dumps(locales, ensure_ascii=False) + ';\n')
print('Generated English and Arabic pages with',len(keys),'translated template fields.')
